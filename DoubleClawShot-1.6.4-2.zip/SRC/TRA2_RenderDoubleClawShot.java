package net.minecraft.src;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.Vec3;

import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL12;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class TRA2_RenderDoubleClawShot extends Render
{
    private static final ResourceLocation field_110792_a = new ResourceLocation("textures/items/clawshots.png");

    public void doRenderFishHook(TRA2_EntityDoubleClawShot par1TRA2_EntityDoubleClawShot, double par2, double par4, double par6, float par8, float par9)
    {
    	bindEntityTexture(par1TRA2_EntityDoubleClawShot);
        GL11.glPushMatrix();
        GL11.glTranslatef((float)par2, (float)par4, (float)par6);
        GL11.glRotatef(par1TRA2_EntityDoubleClawShot.prevRotationYaw + (par1TRA2_EntityDoubleClawShot.rotationYaw - par1TRA2_EntityDoubleClawShot.prevRotationYaw) * par9 - 90.0F, 0.0F, 1.0F, 0.0F);
        GL11.glRotatef(par1TRA2_EntityDoubleClawShot.prevRotationPitch + (par1TRA2_EntityDoubleClawShot.rotationPitch - par1TRA2_EntityDoubleClawShot.prevRotationPitch) * par9, 0.0F, 0.0F, 1.0F);
        Tessellator var10 = Tessellator.instance;
        byte var11 = 0;
        float var12 = 0.0F;
        float var13 = 0.5F;
        float var14 = (float)(0 + var11 * 10) / 32.0F;
        float var15 = (float)(5 + var11 * 10) / 32.0F;
        float var16 = 0.0F;
        float var17 = 0.15625F;
        float var18 = (float)(5 + var11 * 10) / 32.0F;
        float var19 = (float)(10 + var11 * 10) / 32.0F;
        float var20 = 0.05625F;
        GL11.glEnable(GL12.GL_RESCALE_NORMAL);
        float var21 = (float)par1TRA2_EntityDoubleClawShot.arrowShake - par9;

        if (var21 > 0.0F)
        {
            float var22 = -MathHelper.sin(var21 * 3.0F) * var21;
            GL11.glRotatef(var22, 0.0F, 0.0F, 1.0F);
        }

        GL11.glRotatef(45.0F, 1.0F, 0.0F, 0.0F);
        GL11.glScalef(var20, var20, var20);
        GL11.glTranslatef(-4.0F, 0.0F, 0.0F);
        GL11.glNormal3f(var20, 0.0F, 0.0F);
        var10.startDrawingQuads();
        var10.addVertexWithUV(-7.0D, -2.0D, -2.0D, (double)var16, (double)var18);
        var10.addVertexWithUV(-7.0D, -2.0D, 2.0D, (double)var17, (double)var18);
        var10.addVertexWithUV(-7.0D, 2.0D, 2.0D, (double)var17, (double)var19);
        var10.addVertexWithUV(-7.0D, 2.0D, -2.0D, (double)var16, (double)var19);
        var10.draw();
        GL11.glNormal3f(-var20, 0.0F, 0.0F);
        var10.startDrawingQuads();
        var10.addVertexWithUV(-7.0D, 2.0D, -2.0D, (double)var16, (double)var18);
        var10.addVertexWithUV(-7.0D, 2.0D, 2.0D, (double)var17, (double)var18);
        var10.addVertexWithUV(-7.0D, -2.0D, 2.0D, (double)var17, (double)var19);
        var10.addVertexWithUV(-7.0D, -2.0D, -2.0D, (double)var16, (double)var19);
        var10.draw();

        for (int var23 = 0; var23 < 4; ++var23)
        {
            GL11.glRotatef(90.0F, 1.0F, 0.0F, 0.0F);
            GL11.glNormal3f(0.0F, 0.0F, var20);
            var10.startDrawingQuads();
            var10.addVertexWithUV(-8.0D, -2.0D, 0.0D, (double)var12, (double)var14);
            var10.addVertexWithUV(8.0D, -2.0D, 0.0D, (double)var13, (double)var14);
            var10.addVertexWithUV(8.0D, 2.0D, 0.0D, (double)var13, (double)var15);
            var10.addVertexWithUV(-8.0D, 2.0D, 0.0D, (double)var12, (double)var15);
            var10.draw();
        }

        this.bindEntityTexture(par1TRA2_EntityDoubleClawShot);
        Tessellator tessellator = Tessellator.instance;
        byte b0 = 1;
        byte b1 = 2;
        float f2 = (float)(b0 * 8 + 0) / 128.0F;
        float f3 = (float)(b0 * 8 + 8) / 128.0F;
        float f4 = (float)(b1 * 8 + 0) / 128.0F;
        float f5 = (float)(b1 * 8 + 8) / 128.0F;
        float f6 = 1.0F;
        float f7 = 0.5F;
        float f8 = 0.5F;
        GL11.glRotatef(180.0F - this.renderManager.playerViewY, 0.0F, 1.0F, 0.0F);
        GL11.glRotatef(-this.renderManager.playerViewX, 1.0F, 0.0F, 0.0F);
        tessellator.startDrawingQuads();
        tessellator.setNormal(0.0F, 1.0F, 0.0F);
        tessellator.addVertexWithUV((double)(0.0F - f7), (double)(0.0F - f8), 0.0D, (double)f2, (double)f5);
        tessellator.addVertexWithUV((double)(f6 - f7), (double)(0.0F - f8), 0.0D, (double)f3, (double)f5);
        tessellator.addVertexWithUV((double)(f6 - f7), (double)(1.0F - f8), 0.0D, (double)f3, (double)f4);
        tessellator.addVertexWithUV((double)(0.0F - f7), (double)(1.0F - f8), 0.0D, (double)f2, (double)f4);
        tessellator.draw();
        GL11.glDisable(GL12.GL_RESCALE_NORMAL);
        GL11.glPopMatrix();

        if (par1TRA2_EntityDoubleClawShot.shootingEntity != null)
        {
            float f9 = par1TRA2_EntityDoubleClawShot.shootingEntity.getSwingProgress(par9);
            float f10 = MathHelper.sin(MathHelper.sqrt_float(f9) * (float)Math.PI);
            Vec3 vec3 = par1TRA2_EntityDoubleClawShot.worldObj.getWorldVec3Pool().getVecFromPool(-0.5D, 0.03D, 0.8D);
            vec3.rotateAroundX(-(par1TRA2_EntityDoubleClawShot.shootingEntity.prevRotationPitch + (par1TRA2_EntityDoubleClawShot.shootingEntity.rotationPitch - par1TRA2_EntityDoubleClawShot.shootingEntity.prevRotationPitch) * par9) * (float)Math.PI / 180.0F);
            vec3.rotateAroundY(-(par1TRA2_EntityDoubleClawShot.shootingEntity.prevRotationYaw + (par1TRA2_EntityDoubleClawShot.shootingEntity.rotationYaw - par1TRA2_EntityDoubleClawShot.shootingEntity.prevRotationYaw) * par9) * (float)Math.PI / 180.0F);
            vec3.rotateAroundY(f10 * 0.5F);
            vec3.rotateAroundX(-f10 * 0.7F);
            double d3 = par1TRA2_EntityDoubleClawShot.shootingEntity.prevPosX + (par1TRA2_EntityDoubleClawShot.shootingEntity.posX - par1TRA2_EntityDoubleClawShot.shootingEntity.prevPosX) * (double)par9 + vec3.xCoord;
            double d4 = par1TRA2_EntityDoubleClawShot.shootingEntity.prevPosY + (par1TRA2_EntityDoubleClawShot.shootingEntity.posY - par1TRA2_EntityDoubleClawShot.shootingEntity.prevPosY) * (double)par9 + vec3.yCoord;
            double d5 = par1TRA2_EntityDoubleClawShot.shootingEntity.prevPosZ + (par1TRA2_EntityDoubleClawShot.shootingEntity.posZ - par1TRA2_EntityDoubleClawShot.shootingEntity.prevPosZ) * (double)par9 + vec3.zCoord;
            double d6 = par1TRA2_EntityDoubleClawShot.shootingEntity == Minecraft.getMinecraft().thePlayer ? 0.0D : (double)par1TRA2_EntityDoubleClawShot.shootingEntity.getEyeHeight();

            if (this.renderManager.options.thirdPersonView > 0 || par1TRA2_EntityDoubleClawShot.shootingEntity != Minecraft.getMinecraft().thePlayer)
            {
                float f11 = (par1TRA2_EntityDoubleClawShot.shootingEntity.prevRenderYawOffset + (par1TRA2_EntityDoubleClawShot.shootingEntity.renderYawOffset - par1TRA2_EntityDoubleClawShot.shootingEntity.prevRenderYawOffset) * par9) * (float)Math.PI / 180.0F;
                double d7 = (double)MathHelper.sin(f11);
                double d8 = (double)MathHelper.cos(f11);
                d3 = par1TRA2_EntityDoubleClawShot.shootingEntity.prevPosX + (par1TRA2_EntityDoubleClawShot.shootingEntity.posX - par1TRA2_EntityDoubleClawShot.shootingEntity.prevPosX) * (double)par9 - d8 * 0.35D - d7 * 0.85D;
                d4 = par1TRA2_EntityDoubleClawShot.shootingEntity.prevPosY + d6 + (par1TRA2_EntityDoubleClawShot.shootingEntity.posY - par1TRA2_EntityDoubleClawShot.shootingEntity.prevPosY) * (double)par9 - 0.45D;
                d5 = par1TRA2_EntityDoubleClawShot.shootingEntity.prevPosZ + (par1TRA2_EntityDoubleClawShot.shootingEntity.posZ - par1TRA2_EntityDoubleClawShot.shootingEntity.prevPosZ) * (double)par9 - d7 * 0.35D + d8 * 0.85D;
            }

            double d9 = par1TRA2_EntityDoubleClawShot.prevPosX + (par1TRA2_EntityDoubleClawShot.posX - par1TRA2_EntityDoubleClawShot.prevPosX) * (double)par9;
            double d10 = par1TRA2_EntityDoubleClawShot.prevPosY + (par1TRA2_EntityDoubleClawShot.posY - par1TRA2_EntityDoubleClawShot.prevPosY) * (double)par9 + 0.25D;
            double d11 = par1TRA2_EntityDoubleClawShot.prevPosZ + (par1TRA2_EntityDoubleClawShot.posZ - par1TRA2_EntityDoubleClawShot.prevPosZ) * (double)par9;
            double d12 = (double)((float)(d3 - d9));
            double d13 = (double)((float)(d4 - d10));
            double d14 = (double)((float)(d5 - d11));
            GL11.glDisable(GL11.GL_TEXTURE_2D);
            GL11.glDisable(GL11.GL_LIGHTING);
            tessellator.startDrawing(3);
            tessellator.setColorOpaque_I(0);
            byte b2 = 16;

            for (int i = 0; i <= b2; ++i)
            {
                float f12 = (float)i / (float)b2;
                tessellator.addVertex(par2 + d12 * (double)f12, par4 + d13 * (double)f12, par6 + d14 * (double)f12);
            }

            tessellator.draw();
            GL11.glEnable(GL11.GL_LIGHTING);
            GL11.glEnable(GL11.GL_TEXTURE_2D);
        }
    }

    protected ResourceLocation func_110791_a(TRA2_EntityDoubleClawShot par1TRA2_EntityDoubleClawShot)
    {
        return field_110792_a;
    }

    protected ResourceLocation getEntityTexture(Entity par1Entity)
    {
        return this.func_110791_a((TRA2_EntityDoubleClawShot)par1Entity);
    }

    public void doRender(Entity par1Entity, double par2, double par4, double par6, float par8, float par9)
    {
        this.doRenderFishHook((TRA2_EntityDoubleClawShot)par1Entity, par2, par4, par6, par8, par9);
    }
}
