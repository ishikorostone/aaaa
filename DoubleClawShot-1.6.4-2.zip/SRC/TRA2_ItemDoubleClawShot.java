package net.minecraft.src;

import java.util.List;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;


public class TRA2_ItemDoubleClawShot extends Item {

	public TRA2_ItemDoubleClawShot(int i) {
		super(i);
		setTextureName("DoubleClawShot");
		maxStackSize = 1;
	}
	
	@Override
	public void onUpdate(ItemStack itemstack, World world, Entity entity, int i, boolean flag) {
		if(mod_DoubleClawShot.mc != null)
		{
			if(entity != null)
	    	{
				if(entity instanceof EntityPlayer){
					double speed = -1;
					EntityPlayer entityplayer = (EntityPlayer) entity;
					TRA2_EntityDoubleClawShot claw1 = null;
					TRA2_EntityDoubleClawShot claw2 = null;
					if (getClaw1Id(itemstack) != 0 || getClaw2Id(itemstack) != 0)
		            {
		    			List l1list = world.getEntitiesWithinAABB(TRA2_EntityDoubleClawShot.class, entityplayer.boundingBox.expand(64.0D, 64.0D, 64.0D));
		                if(l1list!=null){
		                    for (int lj = 0; lj < l1list.size(); lj++) {
		                       
		                    	TRA2_EntityDoubleClawShot entity2 = (TRA2_EntityDoubleClawShot)l1list.get(lj);
		                	   
		                    	if(entity2 != null){
		    	                	if(entity2.entityId == getClaw1Id(itemstack)){
		    	                		claw1 = entity2;
		    	                		claw1.shootingEntity = entityplayer;
		    	                	}
		    	                	if(entity2.entityId == getClaw2Id(itemstack)){
		    	                		claw2 = entity2;
		    	                		claw2.shootingEntity = entityplayer;
		    	                	}
		                    	}
		                    }
		                }
		                if(claw1 == null)
		                {
		                	if(claw2 != null)
		                	{
		                		claw1 = claw2;
		                		claw2 = null;
		                		setClaw1Id(itemstack, getClaw2Id(itemstack));
		                	}
		                	else
		                	{
		                		setClaw1Id(itemstack, 0);
		                	}
		                }
		                if(claw2 == null)
		                {
		                	setClaw2Id(itemstack, 0);
		                }
		            }
					// (このアイテムを選択中　かつ　左クリック中) または　(スニーク中　かつ　ジャンプ中)
		    		if ((itemstack == entityplayer.getCurrentEquippedItem() && mod_DoubleClawShot.mc.gameSettings.keyBindAttack.pressed)
		    				|| (mod_DoubleClawShot.mc.gameSettings.keyBindSneak.pressed && mod_DoubleClawShot.mc.gameSettings.keyBindJump.pressed))
	    			{
		    			if(claw1 != null)
		    			{
		    				claw1.setDead();
		    			}
		    			if(claw2 != null)
		    			{
		    				claw2.setDead();
		    			}
	    				setClaw1Id(itemstack, 0);
	    				setClaw2Id(itemstack, 0);
	    				setMode(itemstack, 0);
	    			}
		    		else
		    		{
	    				if(claw2 != null)
	    	    		{
	    	    			boolean lflag = false;
	        				if(claw1 != null)
	        				{
	        					if(claw1.count != 0)
	        					{
	        						lflag = true;
	        					}
	        				}
	        				
	    	    			if((lflag && getMode(itemstack) == 2) ||
	    	    					(!lflag && claw2.count != 0 && getMode(itemstack) == 1))
	    	    			{
	    	    				double X6 = entityplayer.posX;
				    			double Z6 = entityplayer.posZ;
				    			double X7;
				    			double Z7;
				    			if(lflag)
				    			{
				    				X7 = claw1.posX;
					    			Z7 = claw1.posZ;
				    			}
				    			else
				    			{
				    				X7 = claw2.posX;
					    			Z7 = claw2.posZ;
				    			}
				    			double X8 = X6 - X7;
				    			double Z8 = Z6 - Z7;
				    			//　極座標に変換
				    			double XZ8 = Math.sqrt((X8*X8)+(Z8*Z8));
				    			if(XZ8 > 0.5D)
				    			{
				    				if(claw1 != null)
					    			{
					    				claw1.setDead();
					    			}
					    			if(claw2 != null)
					    			{
					    				claw2.setDead();
					    			}
				    				setClaw1Id(itemstack, 0);
				    				setClaw2Id(itemstack, 0);
				    				setMode(itemstack, 0);
				    			}
				    			else
				    			{
		    	    				//　落下値をリセット
		    	    				entityplayer.fallDistance = 0;
		    	    				entityplayer.motionX = 0;
		    	    				entityplayer.motionY = 0;
		    	    				entityplayer.motionZ = 0;
		    	    				if (mod_DoubleClawShot.mc.gameSettings.keyBindSneak.pressed)
	    		    				{
	    		    					entityplayer.motionY = -0.25D;
	    		    				}
	    	    					else if (mod_DoubleClawShot.mc.gameSettings.keyBindJump.pressed)
	    		    				{
	    	    						if(lflag)
	    	    						{
	    	    							if(entityplayer.posY < claw1.posY)
	    	    							{
	    	    								entityplayer.motionY = 0.25D;
	    	    							}
	    	    						}
	    	    						else
	    	    						{
	    	    							if(entityplayer.posY < claw2.posY)
	    	    							{
	    	    								entityplayer.motionY = 0.25D;
	    	    							}
	    	    						}
	    		    				}
				    			}
	    	    			}
	    	    			else
	    	    			{
	    	    				if(lflag)
	    	    				{
	    	    					if(claw2 != null)
	    	    	    			{
	    	    	    				claw2.setDead();
	    	    	    			}
	    	        				setClaw2Id(itemstack, 0);
	    	        				setMode(itemstack, 0);
	    	    					double X6 = entityplayer.posX;
	    	    					double EH = entityplayer.getEyeHeight();
	    		    				if(entityplayer.posY + EH > claw1.posY)
	    		    				{
	    		    					EH = 0;
	    		    				}
	    			    			double Y6 = entityplayer.posY + EH;
	    			    			double Z6 = entityplayer.posZ;
	    			    			double X7 = claw1.posX;
	    			    			double Y7 = claw1.posY;
	    			    			double Z7 = claw1.posZ;
	    			    			double X8 = X6 - X7;
	    			    			double Y8 = Y6 - Y7;
	    			    			double Z8 = Z6 - Z7;
	    			    			//　極座標に変換
	    			    			double XZ8 = Math.sqrt((X8*X8)+(Z8*Z8));
	    			    			double XYZ8 = Math.sqrt((XZ8*XZ8)+(Y8*Y8));
	    			    			if(XYZ8 > 0.5D)
	    			    			{
	    				    			double var1 = entityplayer.posX - claw1.posX;
	    				                double var3 = entityplayer.posY + entityplayer.getEyeHeight() - claw1.posY;
	    				                double var5 = entityplayer.posZ - claw1.posZ;
	    				                double var7 = (double)MathHelper.sqrt_double(var1 * var1 + var5 * var5);
	    				                float var9 = (float)(Math.atan2(var5, var1) * 180.0D / Math.PI) - 90.0F;
	    				                float var10 = (float)(-(Math.atan2(var3, var7) * 180.0D / Math.PI));
	    				                float pitch = MathHelper.wrapAngleTo180_float(var10);
	    				                float yaw = MathHelper.wrapAngleTo180_float(var9);
	    				                double X = (double)(-MathHelper.sin(yaw / 180.0F * (float)Math.PI) * MathHelper.cos(pitch / 180.0F * (float)Math.PI));
	    				                double Z = (double)(MathHelper.cos(yaw / 180.0F * (float)Math.PI) * MathHelper.cos(pitch / 180.0F * (float)Math.PI));
	    				                double Y = (double)(-MathHelper.sin(pitch / 180.0F * (float)Math.PI));
	    				                float var90 = MathHelper.sqrt_double(X * X + Y * Y + Z * Z);
	    				                X /= (double)var90;
	    				                Y /= (double)var90;
	    				                Z /= (double)var90;
	    				                X *= (double)speed;
	    				                Y *= (double)speed;
	    				                Z *= (double)speed;
	    				                entityplayer.motionX = X;
	    				                entityplayer.motionY = Y;
	    				                entityplayer.motionZ = Z;
	    				                if(entityplayer.motionY > 0)
	    				                {
	    				                	entityplayer.fallDistance = 0;
	    				                }
	    				                if (mod_DoubleClawShot.mc.gameSettings.keyBindSneak.pressed)
	        		    				{
	    				                	if(entityplayer.motionY < 0)
	    	    							{
	    	    								entityplayer.motionY += -0.25D;
	    	    							}
	    				                	else
	    				                	{
	    				                		entityplayer.motionY = -0.25D;
	    				                	}
	        		    					if(XZ8 < 0.4D)
	        		    					{
	        		    						entityplayer.motionX = 0;
	            				                entityplayer.motionZ = 0;
	            				                setMode(itemstack, 2);
	        		    					}
	        		    				}
	        	    					else if (mod_DoubleClawShot.mc.gameSettings.keyBindJump.pressed)
	        		    				{
	        	    						if(entityplayer.posY < claw1.posY)
	        	    						{
	        	    							entityplayer.motionX *= 1.25D;
	        	    							entityplayer.motionY *= 1.25D;
	        	    							entityplayer.motionZ *= 1.25D;
	        	    						}
	        		    				}
	    			    			}
	    			    			else
	    			    			{
	    			    				if (mod_DoubleClawShot.mc.gameSettings.keyBindJump.pressed)
	        		    				{
	    			    					if(claw1 != null)
	    			    	    			{
	    			    	    				claw1.setDead();
	    			    	    			}
	    			    	    			if(claw2 != null)
	    			    	    			{
	    			    	    				claw2.setDead();
	    			    	    			}
	    			        				setClaw1Id(itemstack, 0);
	    			        				setClaw2Id(itemstack, 0);
	    			        				setMode(itemstack, 0);
	        		    				}
	    			    				else
	    			    				{
	    			    					entityplayer.fallDistance = 0;
	        			    				entityplayer.motionX = 0;
	        				                entityplayer.motionY = 0;
	        				                entityplayer.motionZ = 0;
	        				                setMode(itemstack, 2);
	    			    				}
	    			    			}
	    	    				}
	    	    				else if(claw2.count != 0)
	    		    			{
	    		    				double X6 = entityplayer.posX;
	    		    				double EH = entityplayer.getEyeHeight();
	    		    				if(entityplayer.posY + EH > claw2.posY)
	    		    				{
	    		    					EH = 0;
	    		    				}
	    			    			double Y6 = entityplayer.posY + EH;
	    			    			double Z6 = entityplayer.posZ;
	    			    			double X7 = claw2.posX;
	    			    			double Y7 = claw2.posY;
	    			    			double Z7 = claw2.posZ;
	    			    			double X8 = X6 - X7;
	    			    			double Y8 = Y6 - Y7;
	    			    			double Z8 = Z6 - Z7;
	    			    			//　極座標に変換
	    			    			double XZ8 = Math.sqrt((X8*X8)+(Z8*Z8));
	    			    			double XYZ8 = Math.sqrt((XZ8*XZ8)+(Y8*Y8));
	    			    			if(XYZ8 > 0.5D)
	    			    			{
	    				    			double var1 = entityplayer.posX - claw2.posX;
	    				                double var3 = entityplayer.posY + entityplayer.getEyeHeight() - claw2.posY;
	    				                double var5 = entityplayer.posZ - claw2.posZ;
	    				                double var7 = (double)MathHelper.sqrt_double(var1 * var1 + var5 * var5);
	    				                float var9 = (float)(Math.atan2(var5, var1) * 180.0D / Math.PI) - 90.0F;
	    				                float var10 = (float)(-(Math.atan2(var3, var7) * 180.0D / Math.PI));
	    				                float pitch = MathHelper.wrapAngleTo180_float(var10);
	    				                float yaw = MathHelper.wrapAngleTo180_float(var9);
	    				                double X = (double)(-MathHelper.sin(yaw / 180.0F * (float)Math.PI) * MathHelper.cos(pitch / 180.0F * (float)Math.PI));
	    				                double Z = (double)(MathHelper.cos(yaw / 180.0F * (float)Math.PI) * MathHelper.cos(pitch / 180.0F * (float)Math.PI));
	    				                double Y = (double)(-MathHelper.sin(pitch / 180.0F * (float)Math.PI));
	    				                float var90 = MathHelper.sqrt_double(X * X + Y * Y + Z * Z);
	    				                X /= (double)var90;
	    				                Y /= (double)var90;
	    				                Z /= (double)var90;
	    				                X *= (double)speed;
	    				                Y *= (double)speed;
	    				                Z *= (double)speed;
	    				                entityplayer.motionX = X;
	    				                entityplayer.motionY = Y;
	    				                entityplayer.motionZ = Z;
	    				                if(entityplayer.motionY > 0)
	    				                {
	    				                	entityplayer.fallDistance = 0;
	    				                }
	    				                if (mod_DoubleClawShot.mc.gameSettings.keyBindSneak.pressed)
	        		    				{
	    				                	if(entityplayer.motionY < 0)
	    	    							{
	    	    								entityplayer.motionY += -0.25D;
	    	    							}
	    				                	else
	    				                	{
	    				                		entityplayer.motionY = -0.25D;
	    				                	}
	        		    					if(XZ8 < 0.4D)
	        		    					{
	        		    						entityplayer.motionX = 0;
	            				                entityplayer.motionZ = 0;
	            				                setMode(itemstack, 1);
	        		    					}
	        		    				}
	        	    					else if (mod_DoubleClawShot.mc.gameSettings.keyBindJump.pressed)
	        		    				{
	        	    						if(entityplayer.posY < claw2.posY)
	        	    						{
	        	    							entityplayer.motionX *= 1.25D;
	        	    							entityplayer.motionY *= 1.25D;
	        	    							entityplayer.motionZ *= 1.25D;
	        	    						}
	        		    				}
	    			    			}
	    			    			else
	    			    			{
	    			    				if (mod_DoubleClawShot.mc.gameSettings.keyBindJump.pressed)
	        		    				{
	    			    					if(claw1 != null)
	    			    	    			{
	    			    	    				claw1.setDead();
	    			    	    			}
	    			    	    			if(claw2 != null)
	    			    	    			{
	    			    	    				claw2.setDead();
	    			    	    			}
	    			        				setClaw1Id(itemstack, 0);
	    			        				setClaw2Id(itemstack, 0);
	    			        				setMode(itemstack, 0);
	        		    				}
	    			    				else
	    			    				{
	    			    					entityplayer.fallDistance = 0;
	        			    				entityplayer.motionX = 0;
	        				                entityplayer.motionY = 0;
	        				                entityplayer.motionZ = 0;
	        				                setMode(itemstack, 1);
	    			    				}
	    			    			}
	    		    			}
	    	    			}
	    	    		}
	    	    		else if(claw1 != null)
	    	    		{
	    	    			if(getMode(itemstack) == 2)
	    	    			{
	    	    				setMode(itemstack, 0);
	    	    			}
	    	    			if(getMode(itemstack) == 1)
	    	    			{
	    	    				double X6 = entityplayer.posX;
				    			double Z6 = entityplayer.posZ;
				    			double X7 = claw1.posX;
				    			double Z7 = claw1.posZ;
				    			double X8 = X6 - X7;
				    			double Z8 = Z6 - Z7;
				    			//　極座標に変換
				    			double XZ8 = Math.sqrt((X8*X8)+(Z8*Z8));
				    			if(XZ8 > 0.5D)
				    			{
				    				if(claw1 != null)
					    			{
					    				claw1.setDead();
					    			}
				    				setClaw1Id(itemstack, 0);
				    				setClaw2Id(itemstack, 0);
				    				setMode(itemstack, 0);
				    			}
				    			else
				    			{
		    	    				//　落下値をリセット
		    	    				entityplayer.fallDistance = 0;
		    	    				entityplayer.motionX = 0;
		    	    				entityplayer.motionY = 0;
		    	    				entityplayer.motionZ = 0;
		    	    				if (mod_DoubleClawShot.mc.gameSettings.keyBindSneak.pressed)
	    		    				{
	    		    					entityplayer.motionY = -0.25D;
	    		    				}
	    	    					else if (mod_DoubleClawShot.mc.gameSettings.keyBindJump.pressed)
	    		    				{
	    	    						if(entityplayer.posY < claw1.posY)
	    	    						{
	    	    							entityplayer.motionY = 0.25D;
	    	    						}
	    		    				}
				    			}
	    	    			}
	    	    			else
	    	    			{
	    	    				if(claw1.count != 0)
	    		    			{
	    		    				double X6 = entityplayer.posX;
	    		    				double EH = entityplayer.getEyeHeight();
	    		    				if(entityplayer.posY + EH > claw1.posY)
	    		    				{
	    		    					EH = 0;
	    		    				}
	    			    			double Y6 = entityplayer.posY + EH;
	    			    			double Z6 = entityplayer.posZ;
	    			    			double X7 = claw1.posX;
	    			    			double Y7 = claw1.posY;
	    			    			double Z7 = claw1.posZ;
	    			    			double X8 = X6 - X7;
	    			    			double Y8 = Y6 - Y7;
	    			    			double Z8 = Z6 - Z7;
	    			    			//　極座標に変換
	    			    			double XZ8 = Math.sqrt((X8*X8)+(Z8*Z8));
	    			    			double XYZ8 = Math.sqrt((XZ8*XZ8)+(Y8*Y8));
	    			    			if(XYZ8 > 0.5D)
	    			    			{
	    				    			double var1 = entityplayer.posX - claw1.posX;
	    				                double var3 = entityplayer.posY + entityplayer.getEyeHeight() - claw1.posY;
	    				                double var5 = entityplayer.posZ - claw1.posZ;
	    				                double var7 = (double)MathHelper.sqrt_double(var1 * var1 + var5 * var5);
	    				                float var9 = (float)(Math.atan2(var5, var1) * 180.0D / Math.PI) - 90.0F;
	    				                float var10 = (float)(-(Math.atan2(var3, var7) * 180.0D / Math.PI));
	    				                float pitch = MathHelper.wrapAngleTo180_float(var10);
	    				                float yaw = MathHelper.wrapAngleTo180_float(var9);
	    				                double X = (double)(-MathHelper.sin(yaw / 180.0F * (float)Math.PI) * MathHelper.cos(pitch / 180.0F * (float)Math.PI));
	    				                double Z = (double)(MathHelper.cos(yaw / 180.0F * (float)Math.PI) * MathHelper.cos(pitch / 180.0F * (float)Math.PI));
	    				                double Y = (double)(-MathHelper.sin(pitch / 180.0F * (float)Math.PI));
	    				                float var90 = MathHelper.sqrt_double(X * X + Y * Y + Z * Z);
	    				                X /= (double)var90;
	    				                Y /= (double)var90;
	    				                Z /= (double)var90;
	    				                X *= (double)speed;
	    				                Y *= (double)speed;
	    				                Z *= (double)speed;
	    				                entityplayer.motionX = X;
	    				                entityplayer.motionY = Y;
	    				                entityplayer.motionZ = Z;
	    				                if(entityplayer.motionY > 0)
	    				                {
	    				                	entityplayer.fallDistance = 0;
	    				                }
	    				                if (mod_DoubleClawShot.mc.gameSettings.keyBindSneak.pressed)
	        		    				{
	    				                	if(entityplayer.motionY < 0)
	    	    							{
	    	    								entityplayer.motionY += -0.25D;
	    	    							}
	    				                	else
	    				                	{
	    				                		entityplayer.motionY = -0.25D;
	    				                	}
	        		    					if(XZ8 < 0.4D)
	        		    					{
	        		    						entityplayer.motionX = 0;
	            				                entityplayer.motionZ = 0;
	            				                setMode(itemstack, 1);
	        		    					}
	        		    				}
	        	    					else if (mod_DoubleClawShot.mc.gameSettings.keyBindJump.pressed)
	        		    				{
	        	    						if(entityplayer.posY < claw1.posY)
	        	    						{
	        	    							entityplayer.motionX *= 1.25D;
	        	    							entityplayer.motionY *= 1.25D;
	        	    							entityplayer.motionZ *= 1.25D;
	        	    						}
	        		    				}
	    			    			}
	    			    			else
	    			    			{
	    			    				if (mod_DoubleClawShot.mc.gameSettings.keyBindJump.pressed)
	        		    				{
	    			    					if(claw1 != null)
	    			    	    			{
	    			    	    				claw1.setDead();
	    			    	    			}
	    			        				setClaw1Id(itemstack, 0);
	    			        				setClaw2Id(itemstack, 0);
	    			        				setMode(itemstack, 0);
	        		    				}
	    			    				else
	    			    				{
	    			    					entityplayer.fallDistance = 0;
	        			    				entityplayer.motionX = 0;
	        				                entityplayer.motionY = 0;
	        				                entityplayer.motionZ = 0;
	        				                setMode(itemstack, 1);
	    			    				}
	    			    			}
	    		    			}
	    	    			}
	    	    		}
	    			}
				}
	    	}
		}
	}

    public ItemStack onItemRightClick(ItemStack itemstack, World world, EntityPlayer entityplayer)
    {
    	if(entityplayer != null)
    	{
			TRA2_EntityDoubleClawShot claw1 = null;
			TRA2_EntityDoubleClawShot claw2 = null;
    		if (getClaw1Id(itemstack) != 0 || getClaw2Id(itemstack) != 0)
            {
    			List l1list = world.getEntitiesWithinAABB(TRA2_EntityDoubleClawShot.class, entityplayer.boundingBox.expand(64.0D, 64.0D, 64.0D));
                if(l1list!=null){
                    for (int lj = 0; lj < l1list.size(); lj++) {
                       
                    	TRA2_EntityDoubleClawShot entity2 = (TRA2_EntityDoubleClawShot)l1list.get(lj);
                	   
                    	if(entity2 != null){
    	                	if(entity2.entityId == getClaw1Id(itemstack)){
    	                		claw1 = entity2;
    	                	}
    	                	if(entity2.entityId == getClaw2Id(itemstack)){
    	                		entity2.setDead();
    	                	}
                    	}
                    }
                }
                if(claw1 == null)
                {
                	setClaw1Id(itemstack, 0);
                }
                if(claw2 == null)
                {
                	setClaw2Id(itemstack, 0);
                }
            }
    		world.playSoundAtEntity(entityplayer, "random.bow", 0.5F, 0.4F / (itemRand.nextFloat() * 0.4F + 0.8F));

            if (!world.isRemote)
            {
            	TRA2_EntityDoubleClawShot entity = new TRA2_EntityDoubleClawShot(world, entityplayer, 2.0F);
                world.spawnEntityInWorld(entity);
                setClaw2Id(itemstack, getClaw1Id(itemstack));
                setClaw1Id(itemstack, entity.entityId);
            }

    	}

        return itemstack;
    }
    
    //　１本目発射時は１本目のID　２本目発射時は２本目のID
    public int getClaw1Id(ItemStack pItemstack) {
		checkTags(pItemstack);
		return pItemstack.getTagCompound().getInteger("Claw1Id");
	}

	public void setClaw1Id(ItemStack pItemstack, int pValue) {
		checkTags(pItemstack);
		NBTTagCompound lnbt = pItemstack.getTagCompound();
		lnbt.setInteger("Claw1Id", pValue);
	}
	
	//　２本目発射時は１本目のID
	public int getClaw2Id(ItemStack pItemstack) {
		checkTags(pItemstack);
		return pItemstack.getTagCompound().getInteger("Claw2Id");
	}

	public void setClaw2Id(ItemStack pItemstack, int pValue) {
		checkTags(pItemstack);
		NBTTagCompound lnbt = pItemstack.getTagCompound();
		lnbt.setInteger("Claw2Id", pValue);
	}
	
	//　0：未使用または移動中　1：１本目の傍まで移動した　2：２本目の傍まで移動した
	public int getMode(ItemStack pItemstack) {
		checkTags(pItemstack);
		return pItemstack.getTagCompound().getInteger("Mode");
	}

	public void setMode(ItemStack pItemstack, int pValue) {
		checkTags(pItemstack);
		NBTTagCompound lnbt = pItemstack.getTagCompound();
		lnbt.setInteger("Mode", pValue);
	}
	
	public boolean checkTags(ItemStack pitemstack) {
		// NBTTagの初期化
		if (pitemstack.hasTagCompound()) {
			return true;
		}
		NBTTagCompound ltags = new NBTTagCompound();
		pitemstack.setTagCompound(ltags);
		ltags.setInteger("Claw1Id", 0x0000);
		ltags.setInteger("Claw2Id", 0x0000);
		ltags.setInteger("Mode", 0x0000);
		return false;
	}
}
