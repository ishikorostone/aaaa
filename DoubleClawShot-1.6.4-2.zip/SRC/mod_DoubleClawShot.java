package net.minecraft.src;

import java.util.Map;

import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.entity.RenderItem;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.network.NetServerHandler;
import net.minecraft.network.packet.Packet23VehicleSpawn;
import net.minecraft.network.packet.Packet250CustomPayload;
import net.minecraft.util.ResourceLocation;

import org.lwjgl.opengl.GL11;

import cpw.mods.fml.common.registry.EntityRegistry;

public class mod_DoubleClawShot extends BaseMod {

	@MLProp(min = 3000,max = 32000)
	public static int ID_DoubleClawShot = 6263;
	public static Item DoubleClawShot;
	@MLProp()
	public static int entityID_DoubleClawShot = 731;
	
	/*
	@MLProp(info="Default = 1.0")
	public static double PlayerSpeed = 1.0; 
	
	@MLProp(info="Default = 2.0")
	public static float ClawSpeed = (float) 2.0; 
	*/
    
	@Override
	public String getVersion() {
		return "1.6.4-2";
	}

	@Override
	public String getName() {
		return "DoubleClawShot";
	}


	@Override
	public void load() {
		
		int icon;

		if (ID_DoubleClawShot < 0) return; 
		DoubleClawShot = new TRA2_ItemDoubleClawShot(ID_DoubleClawShot - 256).setUnlocalizedName("DoubleClawShot").setCreativeTab(CreativeTabs.tabCombat);
		ModLoader.addName(DoubleClawShot, "Double Claw Shot");
		
		ModLoader.addRecipe(new ItemStack(DoubleClawShot, 1),
	              new Object[] { "II ","IF ","  P", 
	          Character.valueOf('I'), Item.ingotIron,
	          Character.valueOf('F'), Block.fenceIron,
	          Character.valueOf('P'), Block.pistonStickyBase});
		
		EntityRegistry.registerGlobalEntityID(TRA2_EntityDoubleClawShot.class, "DoubleClawShot", entityID_DoubleClawShot);
		EntityRegistry.registerModEntity(TRA2_EntityDoubleClawShot.class, "DoubleClawShot", 0, this, 64, 10, true);
		
		ModLoader.setInGameHook(this, true, false);//Tick毎に下記メソッドを使う場合Loadメソッド内に定義
	}
	
	@Override
	public void addRenderer(Map map) {
		if (ID_DoubleClawShot >= 0) {
			map.put(TRA2_EntityDoubleClawShot.class, new TRA2_RenderDoubleClawShot());
		}
	}
	
	public static Minecraft mc;
	public boolean onTickInGame(float f, Minecraft minecraft)//毎Tick事に呼び出される
	{
		if(minecraft != null)
		{
			if(mc == null)
			{
				mc = minecraft;
			}
		}
		return true;//Tick毎にこのメソッドを使うなら真　使わないなら偽を返す。
	}
	
}