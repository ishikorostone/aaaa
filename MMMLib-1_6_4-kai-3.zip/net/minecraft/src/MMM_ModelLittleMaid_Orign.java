package net.minecraft.src;

public class MMM_ModelLittleMaid_Orign extends MMM_ModelLittleMaidBase {

	/**
	 * コンストラクタは全て継承させること
	 */
	public MMM_ModelLittleMaid_Orign() {
		super();
	}
	/**
	 * コンストラクタは全て継承させること
	 */
	public MMM_ModelLittleMaid_Orign(float psize) {
		super(psize);
	}
	/**
	 * コンストラクタは全て継承させること
	 */
	public MMM_ModelLittleMaid_Orign(float psize, float pyoffset, int pTextureWidth, int pTextureHeight) {
		super(psize, pyoffset, pTextureWidth, pTextureHeight);
	}


	@Override
	public String getUsingTexture() {
		return "default";
	}

}
